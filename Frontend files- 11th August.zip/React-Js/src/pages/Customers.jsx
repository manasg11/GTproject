import React, { useEffect, useState } from "react";
import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Page,
  Selection,
  Resize,
  Inject,
  Toolbar,
  Sort,
  Filter,
  parentsUntil
} from "@syncfusion/ej2-react-grids";

import { customersData, customersGrid } from "../data/dummy";
import { Header } from "../components";
import UploadService from "../services/uploadService";
import moment from 'moment';
import { numberWithCommas } from "../common";

import { Grid, Edit } from '@syncfusion/ej2-grids';
import { getData } from "@syncfusion/ej2/spreadsheet";

// Grid.Inject(Edit,Toolbar);

// let grid = new Grid({
//   editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
//   toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
//   columns: [
//       { field: 'TransactionID', headerText: 'TransactionID', textAlign: 'Right', width: 100,},
//       { field: 'TransactionDate', headerText: 'TransactionDate', width: 150},
//       { field: 'SecurityDesc', headerText: 'SecurityDesc', textAlign: 'left', width: 120, format: 'C2' },
//       { field: 'BuyQty', headerText: 'BuyQty', width: 150 },
//       { field: 'SellQty', headerText: 'SellQty', width: 150 },
//       { field: 'TradeAmount', headerText: 'TradeAmount', width: 150 },
//       { field: 'TradePrice', headerText: 'TradePrice', width: 150 },
//       { field: 'TradeCharge', headerText: 'TradeCharge', width: 150 },
//       { field: 'CapitalFlow', headerText: 'CapitalFlow', width: 150 },
//       { field: 'BrokerName', headerText: 'BrokerName', width: 150 },
//   ],
//   height: 100
// });
// grid.appendTo('#Grid');

// const GridComponent = () => {
//   useEffect(() => {
//     const grid = new Grid({
//       editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
//       toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
//       columns: [
//         { field: 'TransactionID', headerText: 'TransactionID', textAlign: 'Right', width: 100 },
//         { field: 'TransactionDate', headerText: 'TransactionDate', width: 150 },
//         { field: 'SecurityDesc', headerText: 'SecurityDesc', textAlign: 'left', width: 120, format: 'C2' },
//         { field: 'BuyQty', headerText: 'BuyQty', width: 150 },
//         { field: 'SellQty', headerText: 'SellQty', width: 150 },
//         { field: 'TradeAmount', headerText: 'TradeAmount', width: 150 },
//         { field: 'TradePrice', headerText: 'TradePrice', width: 150 },
//         { field: 'TradeCharge', headerText: 'TradeCharge', width: 150 },
//         { field: 'CapitalFlow', headerText: 'CapitalFlow', width: 150 },
//         { field: 'BrokerName', headerText: 'BrokerName', width: 150 },
//       ],
//       height: 315
//     });
//     grid.appendTo('#Grid');
//   }, []);

// };

const Customers = () => {
  const selectionsettings = { persistSelection: true };
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const res = await UploadService.getData();

    if (res?.success) {

      let tmp = res.data?.transectionData?.map((v) => {
        v.TransactionDate = moment(v.TransactionDate).format('DD/MMM/YYYY');
        v.BuyQty = numberWithCommas(v.BuyQty)
        v.SellQty = numberWithCommas(v.SellQty)
        v.TradePrice = numberWithCommas(v.TradePrice)
        v.TradeCharge = numberWithCommas(v.TradeCharge)
        v.TradeAmount = numberWithCommas(v.TradeAmount)
        v.CapitalFlow= numberWithCommas(v.CapitalFlow)
      })

      setData(res.data?.transectionData);
    } else {
      setData([])
    }
  };

  const deleteAll = async () => {
    if(window.confirm('Delete the all item?')){ 
      const res = await UploadService.deleteAllTransaction();
      if(res?.success) {
        getData()
      }
    }
  }
  const toolbarOptions = ['Search','Add', 'Edit', 'Delete', 'Update', 'Cancel'];


  return (
    <div className="m-2 md:m-10 mt-24 p-10 bg-gray-100 rounded-3xl shadow-lg">
  <Header
    category="Page"
    title="Portfolio Data"
    className="text-gray-800 text-4xl font-bold mb-6"
  />

  <div className="delete-button-section">
    <button
      className="bg-gray-800 text-white rounded-lg py-2 px-4 hover:bg-gray-900 cursor-pointer shadow-md transition-shadow"
      onClick={() => { deleteAll() }}
    >
      Delete
    </button>
  </div>

  <GridComponent
    dataSource={data ?? customersData}
    enableHover={true}
    allowPaging
    allowResizing
    pageSettings={{ pageCount: 5 }}
    selectionSettings={selectionsettings}
    editSettings={{ allowEditing: true, allowAdding: true, allowDeleting: true }}
    toolbar={toolbarOptions}
    // editSettings={editing}
    allowSorting
  >
    <ColumnsDirective>
      {/* eslint-disable-next-line react/jsx-props-no-spreading */}
      {customersGrid.map((item, index) => (
        <ColumnDirective key={index} {...item} />
      ))}
    </ColumnsDirective>
    <Inject services={[Resize, Page, Selection, Toolbar, Edit, Sort, Filter, Grid]} />
  </GridComponent>
</div>

  
  
  );
};
<e-column field='TradeAmount' headerText='TradeAmount' textAlign='right'></e-column>



export default Customers;
