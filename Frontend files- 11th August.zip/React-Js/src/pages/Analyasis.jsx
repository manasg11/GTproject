import React, { useCallback, useState } from 'react';
import { DatePickerComponent } from '@syncfusion/ej2-react-calendars';
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import { ChartComponent, SeriesDirective, SeriesCollectionDirective, StackingColumnSeries, Category, Tooltip, Inject, Trendlines, TrendlineDirective, LineSeries, Legend } from '@syncfusion/ej2-react-charts';
import { returnCalculation } from '../data/dummy';
import { Header } from '../components';

const Analyasis = () => {
  const [chartData, setChartData] = useState([
    { x: 'Category 1', y: 10 },
    { x: 'Category 2', y: 20 },
    { x: 'Category 3', y: 15 },
    { x: 'Category 4', y: 30},
    { x: 'Category 5', y: 7},
    { x: 'Category 6', y: 12},
    { x: 'Category 7', y: 32},
    // Add more data as needed
  ]);

  const [dropdownValue, setDropdownValue] = useState({
    returnCalculation: "",
  });

  const fields = { text: "name", value: "id" };

  const handleDropDownChange = useCallback(
    (e) => {
      const selectedValue = e.target.value;
      const selectedName = e.target.name;
      // Do something with the selected value
      setDropdownValue({ ...dropdownValue, [selectedName]: selectedValue });
    },
    [dropdownValue]
  );
  const Table = () => {}

  return (
    <div className="m-2 md:m-10 mt-24 p-6 md:p-12 bg-gradient-to-r from-gray-100 via-gray-200 to-gray-300 rounded-3xl shadow-lg hover:shadow-xl transition-transform" style={{
      position: 'relative',
      transform: 'translateY(0)',
      transition: 'transform 0.3s, box-shadow 0.3s',
    }}
    onMouseEnter={(e) => { e.currentTarget.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.2)'; e.currentTarget.style.transform = 'translateY(-4px)'; }}
    onMouseLeave={(e) => { e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)'; e.currentTarget.style.transform = 'translateY(0)'; }}>
      <Header
        category="Page"
        title="Perform Analysis"
        className="text-white text-3xl font-bold mb-6"
      />
      <div className="flex justify-around items-center w-full">
        <div className="p-2 shadow-md hover:shadow-lg">
          <DatePickerComponent
            id="datepicker"
            placeholder="Start date"
            className="rounded-lg p-3 bg-white shadow-md focus:outline-none focus:ring-2 focus:ring-purple-400"
          />
        </div>
        <div className="p-2 shadow-md hover:shadow-lg">
          <DatePickerComponent
            id="datepicker"
            placeholder="End date"
            className="rounded-lg p-3 bg-white shadow-md focus:outline-none focus:ring-2 focus:ring-purple-400"
          />
        </div>
        <div className="form-group mb-4 rounded-lg bg-white shadow-md hover:shadow-lg">
          <DropDownListComponent
            id="existing-portfolio"
            dataSource={returnCalculation}
            fields={fields}
            name="returnCalculation"
            placeholder="Select Return Calculation"
            onChange={handleDropDownChange}
            popupHeight="200px"
            className="p-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
          />
        </div>
      </div>
      <div className="flex justify-center items-center w-full mt-4">
        <button className="bg-purple-600 hover:bg-purple-700 text-white py-3 px-6 rounded-lg shadow-md transition-colors focus:outline-none focus:ring-2 focus:ring-purple-400">
          Run analysis
        </button>
      </div>
      <div className="w-full mt-6">
        <div className="bg-white rounded-lg shadow-md p-4 relative hover:border-2 hover:border-purple-400">
          <div className="text-xl font-semibold mb-4">Analysis Chart</div>
          <div className="chart-container" style={{
            padding: '8px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            borderRadius: '8px',
            overflow: 'hidden',
            transition: 'box-shadow 0.3s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.boxShadow = '0 0 20px rgba(255, 255, 255, 0.6), 0 0 40px rgba(255, 255, 255, 0.6)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)'; }}>
            <ChartComponent
              id="columnChart"
              primaryXAxis={{ valueType: 'Category' }}
              primaryYAxis={{ title: 'Values' }}
              width="100%"
              height="400px"
              chartArea={{ border: { width: 0 } }}
              tooltip={{ enable: true }}
              legendSettings={{ visible: false }}
            >
              <Inject services={[StackingColumnSeries, Category, Tooltip]} />
              <SeriesCollectionDirective>
                <SeriesDirective dataSource={chartData} xName="x" yName="y" type="StackingColumn" />
              </SeriesCollectionDirective>
            </ChartComponent>
          </div>
        </div>
      </div>
      <div className="w-full mt-6">
        <div className="bg-white rounded-lg shadow-md p-4 relative hover:border-2 hover:border-purple-400">
          <div className="text-xl font-semibold mb-4">Moving Averages Trendline Chart</div>
          <div className="chart-container" style={{
            padding: '8px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            borderRadius: '8px',
            overflow: 'hidden',
            transition: 'box-shadow 0.3s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.boxShadow = '0 0 20px rgba(255, 255, 255, 0.6), 0 0 40px rgba(255, 255, 255, 0.6)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)'; }}>
            <ChartComponent
              id="lineChart"
              primaryXAxis={{ valueType: 'Category' }}
              primaryYAxis={{ title: 'Values' }}
              width="100%"
              height="400px"
              chartArea={{ border: { width: 0 } }}
              tooltip={{ enable: true }}
              legendSettings={{ visible: false }}
            >
              <Inject services={[LineSeries, Category, Tooltip, Trendlines]} />
              <SeriesCollectionDirective>
                <SeriesDirective dataSource={chartData} xName="x" yName="y" type="Line" name="Data" />
              </SeriesCollectionDirective>
              <TrendlineDirective
                type='MovingAverage'
                fill='rgba(255, 0, 0, 0.3)'
                width={2}
                period={3} // You can change the period for your moving average
                animation={{ enable: true, duration: 1000 }}
              />
            </ChartComponent>
          </div>
        </div>
      </div>
      <div className="table-container">
      <table className="styled-table">
        <thead>
          <tr>
            <th>Scheme Inception Date</th>
            <th>52 Week High</th>
            <th>52 Week Low</th>
            <th>Top 5 Holdings</th>
            <th>Weigtage of Top 5 holdings</th>
            <th>Top 3 Sectors</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2020-01-01</td>
            <td>100</td>
            <td>50</td>
            <td>Company A, Company B, Company C, Company D, Company E</td>
            <td>20%, 18%, 15%, 12%, 10%</td>
            <td>Sector X, Sector Y, Sector Z</td>
          </tr>
          {/* Add more rows as needed */}
        </tbody>
      </table>
    </div>
      
    </div>
  );
}

export default Analyasis;
