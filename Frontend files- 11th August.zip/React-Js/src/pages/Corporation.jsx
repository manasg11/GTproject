import React, { useEffect, useState } from "react";
import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Page,
  Selection,
  Inject,
  Edit,
  Toolbar,
  Sort,
  Filter,
  Search,
  Resize,
} from "@syncfusion/ej2-react-grids";

import { corporationGrid, customersData, customersGrid } from "../data/dummy";
import { Header } from "../components";
import UploadService from "../services/uploadService";
import moment from "moment";
import { search } from "@syncfusion/ej2/filemanager";




const Corporation = () => {
  const selectionsettings = { persistSelection: true };
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const res = await UploadService.CorporationgetData();

    if (res?.success) {
      let tmp = res.data?.corporateAction?.map((v) => {
        v.Date = moment(v.Date).format('DD/MMM/YYYY');
        v.ExDate = moment(v.ExDate).format('DD/MMM/YYYY');
        // v.ExDate = numberWithCommas(v.ExDate)
        // v.Cashout = numberWithCommas(v.Cashout)
      })
      setData(res.data?.corporateAction);
    } else {
      setData([])
    }
  };

  const deleteAll = async () => {
    if(window.confirm('Delete the all item?')){ 
      const res = await UploadService.deleteAllCorporate();
      if(res?.success) {
        getData()
      }
    }
  }
  const toolbarOptions = ['Search','Add', 'Edit', 'Delete', 'Update', 'Cancel'];

  const searchOptions = {
        fields: ['SName1'],
        ignoreCase: true,
        operator: 'contains'
    };


  return (
    <div className="m-2 md:m-10 mt-24 p-10 bg-gray-100 rounded-3xl shadow-lg">
  <Header
    category="Page"
    title="corporationData"
    className="text-gray-800 text-4xl font-bold mb-6"
  />
  <div className="delete-button-section">
    <button
      className="bg-gray-800 text-white rounded-lg py-2 px-4 hover:bg-gray-900 cursor-pointer shadow-md transition-shadow"
      onClick={() => { deleteAll() }}
    >
      Delete
    </button>
  </div>

  <GridComponent
    dataSource={data ?? customersData}
    enableHover={false}
    allowPaging
    allowResizing
    editSettings={{ allowEditing: true, allowAdding: true, allowDeleting: true }}
    pageSettings={{ pageCount: 5 }}
    selectionSettings={selectionsettings}
    toolbar={toolbarOptions}
    allowSorting
  >
    <ColumnsDirective>
      {/* eslint-disable-next-line react/jsx-props-no-spreading */}
      {corporationGrid.map((item, index) => (
        <ColumnDirective key={index} {...item} />
      ))}
    </ColumnsDirective>
    <Inject services={[Resize, Page, Selection, Toolbar, Edit, Sort, Filter, Search]} />
  </GridComponent>
</div>

  );
};

export default Corporation;
