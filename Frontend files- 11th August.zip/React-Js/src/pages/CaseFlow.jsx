import React, { useEffect, useState } from "react";
import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Page,
  Selection,
  Inject,
  Edit,
  Toolbar,
  Sort,
  Filter,
  Search,
  Resize,
} from "@syncfusion/ej2-react-grids";

import { caseFlowGrid, customersData } from "../data/dummy";
import { Header } from "../components";
import UploadService from "../services/uploadService";
import moment from 'moment';
import { numberWithCommas } from "../common";
import {Grid} from '@syncfusion/ej2-grids';
import { getData } from "@syncfusion/ej2/spreadsheet";

Grid.Inject(Edit,Toolbar);

const CaseFlow = () => {
  const selectionsettings = { persistSelection: true };
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const res = await UploadService.caseFlowgetData();

    if (res?.success) {
      let tmp = res.data?.cashFlow?.map((v) => {
        v.CashFlowDate = moment(v.CashFlowDate).format('DD/MMM/YYYY');
        v.Cashin = numberWithCommas(v.Cashin)
        v.Cashout = numberWithCommas(v.Cashout)
      })
      setData(res.data?.cashFlow);
    } else {
      setData([])
    }
  };

  const deleteAll = async () => {
    if(window.confirm('Delete the all item?')){ 
      const res = await UploadService.deleteAllCash();
      if(res?.success) {
        getData()
      }
    }
  }
  
  const toolbarOptions = ['Search','Add', 'Edit', 'Delete', 'Update', 'Cancel'];

  const searchOptions = {
        fields: ['CustomerID'],
        ignoreCase: true,
        operator: 'contains'
    };

    // let grid = new Grid({
    //   editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
    //   toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
    //   columns: [
    //       { field: 'CashflowID', headerText: 'CashflowID', textAlign: 'Right', width: 100,},
    //       { field: 'CashFlowDate', headerText: 'CashFlowDate', width: 150},
    //       { field: 'Account', headerText: 'Account', textAlign: 'left', width: 120, format: 'C2' },
    //       { field: 'Description', headerText: 'Description', width: 150 },
    //       { field: 'Cashin', headerText: 'Cashin', width: 150 },
    //       { field: 'Cashout', headerText: 'Cashout', width: 150 },
    //   ],
    //   height: 100
    // });
    // grid.appendTo('#Grid');
    
  
  return (
    <div className="m-2 md:m-10 mt-24 p-10 bg-gray-100 rounded-3xl shadow-lg">
    <Header
      category="Page"
      title="Cash Flow Data"
      className="text-gray-800 text-4xl font-bold mb-6"
    />
    <div className="delete-button-section">
      <button
        className="bg-gray-800 text-white rounded-lg py-2 px-4 hover:bg-gray-900 cursor-pointer shadow-md transition-shadow"
        onClick={() => { deleteAll() }}
      >
        Delete
      </button>
    </div>
    <GridComponent
      dataSource={data ?? customersData}
      enableHover={false}
      allowPaging
      allowResizing
      toolbar={toolbarOptions} 
      pageSettings={{ pageCount: 5 }}
      editSettings={{ allowEditing: true, allowAdding: true, allowDeleting: true }}
      selectionSettings={selectionsettings}
      allowSorting
    >
      <ColumnsDirective>
        {/* eslint-disable-next-line react/jsx-props-no-spreading */}
        {caseFlowGrid.map((item, index) => (
          <ColumnDirective key={index} {...item}  />
        ))}
      </ColumnsDirective>
      <Inject services={[Resize, Page, Selection, Toolbar, Edit, Sort, Filter, Search, Toolbar]} />
    </GridComponent>
  </div>
  

  );
};

export default CaseFlow;
