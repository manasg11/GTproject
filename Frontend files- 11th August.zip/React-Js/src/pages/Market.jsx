import React, { useEffect, useState } from "react";
import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Page,
  Selection,
  Inject,
  Edit,
  Toolbar,
  Sort,
  Filter,
  Resize,
  editSettings
} from "@syncfusion/ej2-react-grids";

import { customersData, marketGrid } from "../data/dummy";
import { Header } from "../components";
import UploadService from "../services/uploadService";
import moment from "moment";

const Market = () => {
  const selectionsettings = { persistSelection: true };
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const res = await UploadService.marketgetData();

    if (res?.success) {

      let tmp = res.data?.closingPrice?.map((v) => {
        v.Date = moment(v.Date).format('DD/MMM/YYYY');
      })
      setData(res.data?.closingPrice);
    } else {
      setData([])
    }
  };

  const toolbarOptions = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];


  const deleteAll = async () => {
    if(window.confirm('Delete the all item?')){ 
      const res = await UploadService.deleteAllClosingPrice();
      if(res?.success) {
        getData()
      }
    }
  }
  

   
  return (
    <div className="m-2 md:m-10 mt-24 p-10 bg-gray-100 rounded-3xl shadow-lg">
  <Header
    category="Page"
    title="Market Data"
    className="text-gray-800 text-4xl font-bold mb-6"
  />
  <div className="delete-button-section">
    <button
      className="bg-gray-800 text-white rounded-lg py-2 px-4 hover:bg-gray-900 cursor-pointer shadow-md transition-shadow"
      onClick={() => { deleteAll() }}
    >
      Delete
    </button>
  </div>

  <GridComponent
    dataSource={data ?? customersData}
    enableHover={false}
    allowPaging
    allowResizing
    editSettings={{allowEditing:true, allowAdding:true, allowDeleting:true}}
    pageSettings={{ pageCount: 5 }}
    selectionSettings={selectionsettings}
    toolbar={toolbarOptions}
    allowSorting
  >
    <ColumnsDirective>
      {/* eslint-disable-next-line react/jsx-props-no-spreading */}
      {marketGrid.map((item, index) => (
        <ColumnDirective key={index} {...item} />
      ))}
    </ColumnsDirective>
    <Inject services={[Edit,Resize,Page, Selection, Toolbar, Edit, Sort, Filter]} />
  </GridComponent>
</div>

  );
};

export default Market;
