import { errorHandler, successHandler } from "../common/appHandler";
import axiosInstance from "../common/axiosInstance";

class UploadService {
  static uploadPortFolioData = async (data) => {
    try {
      const res = await axiosInstance.post(
        "/transection-data/transections-data",
        data
      );
      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static uploadCashflowData = async (data) => {
    try {
      const res = await axiosInstance.post("/cash-flow/cash-flow", data);

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static uploadMarketData = async (data) => {
    try {
      const res = await axiosInstance.post(
        "/closing-price/closing-price",
        data
      );

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static uploadCorporateData = async (data) => {
    try {
      const res = await axiosInstance.post(
        "/corporate-action/corporate-action",
        data
      );

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static getData = async () => {
    try {
      const res = await axiosInstance.get(
        "/transection-data/transection-data"
      );

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static caseFlowgetData = async () => {
    try {
      const res = await axiosInstance.get("/cash-flow/cash-flow");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static marketgetData = async () => {
    try {
      const res = await axiosInstance.get("/closing-price/closing-price");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static CorporationgetData = async () => {
    try {
      const res = await axiosInstance.get("/corporate-action/corporate-action");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static deleteAllClosingPrice = async () => {
    try {
      const res = await axiosInstance.delete("/closing-price/closing-price");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static deleteAllTransaction = async () => {
    try {
      const res = await axiosInstance.delete("/transection-data/transection-data");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static deleteAllCorporate = async () => {
    try {
      const res = await axiosInstance.delete("/corporate-action/corporate-action");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

  static deleteAllCash = async () => {
    try {
      const res = await axiosInstance.delete("/cash-flow/cash-flow");

      return successHandler(res);
    } catch (error) {
      return errorHandler(error);
    }
  };

}

export default UploadService;
