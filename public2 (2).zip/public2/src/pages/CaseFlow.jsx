import React, { useEffect, useState } from "react";
import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Page,
  Selection,
  Inject,
  Edit,
  Toolbar,
  Sort,
  Filter,
  Search,
} from "@syncfusion/ej2-react-grids";

import { caseFlowGrid, customersData } from "../data/dummy";
import { Header } from "../components";
import UploadService from "../services/uploadService";

const CaseFlow = () => {
  const selectionsettings = { persistSelection: true };
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const res = await UploadService.caseFlowgetData();

    if (res?.success) {
      setData(res.data?.cashFlow);
    }
  };

  const toolbarOptions = ['Search'];

  const searchOptions = {
        fields: ['CustomerID'],
        ignoreCase: true,
        operator: 'contains'
    };

  return (
    <div className="m-2 md:m-10 mt-24 p-2 md:p-10 bg-white rounded-3xl">
      <Header category="Page" title="Cash Flow Data" />
      <GridComponent
        dataSource={data ?? customersData}
        enableHover={false}
        allowPaging
        toolbar={toolbarOptions} 
        pageSettings={{ pageCount: 5 }}
        selectionSettings={selectionsettings}
        // toolbar={toolbarOptions}
        // editSettings={editing}
        allowSorting
      >
        <ColumnsDirective>
          {/* eslint-disable-next-line react/jsx-props-no-spreading */}
          {caseFlowGrid.map((item, index) => (
            <ColumnDirective key={index} {...item}  />
          ))}
        </ColumnsDirective>
        <Inject services={[Page, Selection, Toolbar, Edit, Sort, Filter,Search, Toolbar]} />
      </GridComponent>
    </div>
  );
};

export default CaseFlow;
