import { DatePickerComponent } from '@syncfusion/ej2-react-calendars'
import React, { useCallback, useState } from 'react'
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import { returnCalculation } from '../data/dummy';
import { Header } from '../components';

const Analyasis = () => {
  const [dropdownValue, setDropdownValue] = useState({
    returnCalculation: "",
  });

  const fields = { text: "name", value: "id" };

  const handleDropDownChange = useCallback(
    (e) => {
      const selectedValue = e.target.value;
      const selectedName = e.target.name;
      // Do something with the selected value

      setDropdownValue({ ...dropdownValue, [selectedName]: selectedValue });

    },
    [dropdownValue]
  );

  return (
    <div className="m-2 md:m-10 mt-24 p-2 md:p-10 bg-white rounded-3xl ">
        <Header category="Page" title="Perform Analysis" />
        <div className='flex justify-around'>
            <div>
              <DatePickerComponent id="datepicker" placeholder="Start date"/>
            </div>
            <div>
              <DatePickerComponent id="datepicker" placeholder="End date"/>
            </div>
        
            <div className="form-group  mb-4 border">
              <DropDownListComponent
                id="existing-portfolio"
                dataSource={returnCalculation}
                fields={fields}
                name="returnCalculation"
                placeholder="Select Return Calculation"
                onChange={handleDropDownChange}
              />
            </div>
        </div>
    </div>
  )
}

export default Analyasis