import React, { useCallback, useMemo, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import { Nav, Tab } from "react-bootstrap";
import "../App.css";
// import './src/App.css';
// import {
//   GridComponent,
//   ColumnsDirective,
//   ColumnDirective,
//   Page,
//   Selection,
//   Inject,
//   Edit,
//   Toolbar,
//   Sort,
//   Filter,
// } from "@syncfusion/ej2-react-grids";

import {
  customersData,
  customersGrid,
  existingPortFolio,
  newPortFolio,
  portFolioData,
} from "../data/dummy";
import { Header } from "../components";
import { UploaderComponent } from "@syncfusion/ej2-react-inputs";
import { ButtonComponent } from "@syncfusion/ej2-react-buttons";
import * as XLSX from "xlsx";
import UploadService from "../services/uploadService";

const Transactions = () => {
  // const selectionsettings = { persistSelection: true };
  // const toolbarOptions = ["Delete"];
  // const editing = { allowDeleting: true, allowEditing: true };
  const fields = { text: "name", value: "id" };
  const [screen, setScreen] = useState("initial");
  const [activeKey, setActiveKey] = useState("portfolio");
  const [activeTab, setActiveTab] = useState(1);
  const [fileData, setFileData] = useState([]);
  const [dropdownValue, setDropdownValue] = useState({
    existingPortfolio: "",
    newPortfolio: "",
    deletePortfolio: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  let uploaderRef = useRef(null);

  const allowedExtensions = useMemo(() => ".csv, .xls, .xlsx", []);

  const uploadData = async (data) => {
    let response = null;
    if (activeTab === 1)
      response = await UploadService.uploadPortFolioData(data);
    else if (activeTab === 2)
      response = await UploadService.uploadCashflowData(data);
    else if (activeTab === 3)
      response = await UploadService.uploadMarketData(data);
    else if (activeTab === 4)
      response = await UploadService.uploadCorporateData(data);

    return response;
  };

  const submitData = async () => {
    setError("");
    setIsLoading(true);
    const res = await uploadData(fileData);
    if (!res?.success) {
      setError("Something went wrong, please try again!");
    } else {
    }
    setIsLoading(false);
  };

  const onFileSelected = useCallback((args) => {
    // args.filesData.splice(5);
    const file = args.event.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = (e) => {
        const fileData = e.target.result;
        const workbook = XLSX.read(fileData, { type: "binary" });

        workbook.SheetNames.forEach((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          const transformedData = data.slice(1).map((row) => {
            const obj = {};
            data[0].forEach((key, index) => {
              obj[key] = row[index] !== undefined ? row[index] : "";
            });
            return obj;
          });
          setFileData(transformedData);
        });
      };

      reader.readAsBinaryString(file);
    }

    // let allFiles = filesData.concat(args.filesData);
    // if (allFiles.length > 5) {
    //   for (let i = 0; i < allFiles.length; i++) {
    //     if (allFiles.length > 5) {
    //       allFiles.shift();
    //     }
    //   }
    //   args.filesData = allFiles;
    //   args.modifiedFilesData = args.filesData;
    // }
    args.isModified = true;
  }, []);

  const handleDropDownChange = useCallback(
    (e) => {
      const selectedValue = e.target.value;
      const selectedName = e.target.name;
      // Do something with the selected value

      setDropdownValue({ ...dropdownValue, [selectedName]: selectedValue });

      if (selectedName === 'deletePortfolio') {
        setShowConfirmationModal(true);
        console.log('trueee');
      }

    },
    [dropdownValue]
  );

  const handleDeleteConfirmation = () => {
    // Perform delete operation based on selected valu

    // Close the confirmation modal
    setShowConfirmationModal(false);
  };

  const toggleTab = useCallback((tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  }, []);

  return (
    <div className="container">
      <Header category="" title="Upload Portfolio Data" />

      {screen === "initial" && (
        <div className="row  d-flex justify-center ">
          <div className="col-2"></div>

          <div
            className=" bg-light col-8  border border-dark rounded-2xl text-center p-5 "
            style={{ boxShadow: "0 5px 5px  #737373" }}
          >
            <form
              className="form d-flex flex-column"
              onSubmit={(e) => {
                e.preventDefault();
                setScreen("next");
              }}
            >
              <div className="form-group  mb-4 border">
                <DropDownListComponent
                  id="existing-portfolio"
                  dataSource={existingPortFolio}
                  fields={fields}
                  name="existingPortfolio"
                  placeholder="Select Existing Portfolio"
                  onChange={handleDropDownChange}
                />
              </div>

              <div className="form-group mb-4">
                {/* <DropDownListComponent
                  id="new-portfolio"
                  dataSource={newPortFolio}
                  fields={fields}
                  name="newPortfolio"
                  placeholder="Add New Portfolio"
                  onChange={handleDropDownChange}
                /> */}
                <button
                  className="e-input-group text-dark w-full text-left font-bold  text-sm px-6 py-3 rounded hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                  type="button"
                  onClick={() => setShowModal(true)}
                >
                  Add New Portfolio
                </button>
                {showModal ? (
                  <>
                    <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
                      <div className="relative w-auto my-6 mx-auto max-w-3xl">
                        {/*content*/}
                        <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                          {/*header*/}
                          <div className="flex items-start justify-between p-5 border-b border-solid border-slate-200 rounded-t">
                            <h3 className="text-3xl font-semibold">
                              Enter the New of Portfolio
                            </h3>
                          </div>
                          {/*body*/}
                          <div className="relative p-6 flex-auto">
                            <input
                              type="text"
                              placeholder="newPortfolio"
                              className="px-3 py-3 placeholder-slate-300 text-slate-600 relative bg-white bg-white rounded text-sm border-0 shadow outline-none focus:outline-none focus:ring w-full"
                            />
                          </div>
                          {/*footer*/}
                          <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
                            <button
                              className="text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                              type="button"
                              onClick={() => setShowModal(false)}
                            >
                              Close
                            </button>
                            <button
                              className="bg-emerald-500 text-white active:bg-emerald-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                              type="button"
                              onClick={() => setShowModal(false)}
                            >
                              Submit Changes
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
                  </>
                ) : null}
              </div>

              <div className="form-group mb-4 ">
                <DropDownListComponent
                  id="delete-portfolio"
                  dataSource={newPortFolio}
                  fields={fields}
                  name="deletePortfolio"
                  placeholder="Delete Selected Portfolio"
                  onChange={handleDropDownChange}
                />
                {showConfirmationModal && (
                  <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
                    <div className="bg-white rounded-md p-6 max-w-md">
                      <p className="mb-4">
                        Are you sure you want to delete ?
                      </p>
                      <div className="flex justify-end">
                        <button
                          className="mr-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                          onClick={handleDeleteConfirmation}
                        >
                          Delete
                        </button>
                        <button
                          className="px-4 py-2 border border-gray-300 rounded hover:border-gray-400"
                          // onClick={handleCancelConfirmation}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <ButtonComponent
                cssClass="e-info"
                className="!capitalize"
                type="submit"
                style={{ boxShadow: "0 3px 3px #737373" }}
              >
                Next
              </ButtonComponent>
            </form>
          </div>

          <div className="col-2"></div>
        </div>
      )}

      {screen === "next" && (
        <div className="d-flex justify-center ">
          <div
            className="Container p-5 bg-light border border-dark rounded-2xl text-center mt-3 mb-5 w-9/12"
            style={{ boxShadow: "0 5px 5px  #737373" }}
          >
            {error ? <div className="text-rose-700">{error}</div> : null}
            <div className="row d-flex justify-center w-full">
              <div className="mt-4 w-full">
                <Tab.Container defaultActiveKey={activeKey}>
                  <Nav variant="pills" className="d-flex justify-center">
                    {activeTab === 1 && (
                      <Nav.Item className="mr-2">
                        <Nav.Link
                          active={true}
                          eventKey="portfolio"
                          className="font-weight-bold border"
                          style={{ borderRadius: "8px" }}
                        >
                          Upload Portfolio Data
                        </Nav.Link>
                      </Nav.Item>
                    )}

                    {activeTab === 2 && (
                      <Nav.Item className="mr-2">
                        <Nav.Link
                          active={true}
                          eventKey="cashflow"
                          className=" font-weight-bold border "
                          style={{ borderRadius: "8px" }}
                        >
                          Upload Cashflow Data
                        </Nav.Link>
                      </Nav.Item>
                    )}

                    {activeTab === 3 && (
                      <Nav.Item className="mr-2">
                        <Nav.Link
                          active={true}
                          eventKey="market"
                          className="font-weight-bold border  "
                          style={{ borderRadius: "8px" }}
                        >
                          Upload Market Data
                        </Nav.Link>
                      </Nav.Item>
                    )}
                    {activeTab === 4 && (
                      <Nav.Item className="mr-2">
                        <Nav.Link
                          active={true}
                          eventKey="corporate"
                          className="font-weight-bold border "
                          style={{ borderRadius: "8px" }}
                        >
                          Upload Corporate Action Data
                        </Nav.Link>
                      </Nav.Item>
                    )}
                  </Nav>

                  <div className="d-flex justify-end mt-2">
                    {activeTab === 1 && (
                      <a
                        href={portFolioData.portfolio}
                        target="_blank"
                        download
                      >
                        <ButtonComponent
                          cssClass="e-info"
                          className="!capitalize"
                        >
                          Download
                        </ButtonComponent>
                      </a>
                    )}
                    {activeTab === 2 && (
                      <a href={portFolioData.cashflow} target="_blank" download>
                        <ButtonComponent
                          cssClass="e-info"
                          className="!capitalize"
                        >
                          Download
                        </ButtonComponent>
                      </a>
                    )}
                    {activeTab === 3 && (
                      <a href={portFolioData.market} target="_blank" download>
                        <ButtonComponent
                          cssClass="e-info"
                          className="!capitalize"
                        >
                          Download
                        </ButtonComponent>
                      </a>
                    )}
                    {activeTab === 4 && (
                      <a
                        href={portFolioData.corporate}
                        target="_blank"
                        download
                      >
                        <ButtonComponent
                          cssClass="e-info"
                          className="!capitalize"
                        >
                          Download
                        </ButtonComponent>
                      </a>
                    )}
                  </div>
                  <div className="control-pane mt-4">
                    <div className="control-section col-lg-12 uploadpreview p-0 ">
                      <div className="upload_wrapper">
                        <UploaderComponent
                          id="validation"
                          type="file"
                          multiple={false}
                          selected={(args) => onFileSelected(args)}
                          autoUpload={true}
                          allowedExtensions={allowedExtensions}
                        ></UploaderComponent>
                      </div>
                    </div>
                  </div>

                  {/* <Tab.Pane eventKey="cashflow" tabIndex={2}>
                      <div className="d-flex justify-end mt-2">
                        <a
                          href={portFolioData.cashflow}
                          target="_blank"
                          download
                        >
                          <ButtonComponent
                            cssClass="e-info"
                            className="!capitalize"
                          >
                            123
                          </ButtonComponent>
                        </a>
                      </div>
                      <div className="control-pane mt-4">
                        <div className="control-section col-lg-12 uploadpreview p-0 ">
                          <div className="upload_wrapper">
                            <UploaderComponent
                              id="validation-2"
                              type="file"
                              multiple={false}
                              selected={(args) => onFileSelected(args)}
                              autoUpload={true}
                              allowedExtensions={allowedExtensions}
                            ></UploaderComponent>
                          </div>
                        </div>
                      </div>
                    </Tab.Pane>
                    <Tab.Pane eventKey="market" tabIndex={3}>
                      <div className="d-flex justify-end mt-2">
                        <a href={portFolioData.market} target="_blank" download>
                          <ButtonComponent
                            cssClass="e-info"
                            className="!capitalize"
                          >
                            Download
                          </ButtonComponent>
                        </a>
                      </div>

                      <div className="control-pane mt-4">
                        <div className="control-section col-lg-12 uploadpreview p-0 ">
                          <div className="upload_wrapper">
                            <UploaderComponent
                              id="validation-3"
                              type="file"
                              multiple={false}
                              selected={(args) => onFileSelected(args)}
                              autoUpload={true}
                              allowedExtensions={allowedExtensions}
                            ></UploaderComponent>
                          </div>
                        </div>
                      </div>
                    </Tab.Pane>
                    <Tab.Pane eventKey="corporate" tabIndex={4}>
                      <div className="d-flex justify-end mt-2">
                        <a
                          href={portFolioData.corporate}
                          target="_blank"
                          download
                        >
                          <ButtonComponent
                            cssClass="e-info"
                            className="!capitalize"
                          >
                            Download
                          </ButtonComponent>
                        </a>
                      </div>

                      <div className="control-pane mt-4">
                        <div className="control-section col-lg-12 uploadpreview p-0 ">
                          <div className="upload_wrapper">
                            <UploaderComponent
                              id="validation-4"
                              type="file"
                              multiple={false}
                              selected={(args) => onFileSelected(args)}
                              autoUpload={true}
                              allowedExtensions={allowedExtensions}
                            ></UploaderComponent>
                          </div>
                        </div>
                      </div>
                    </Tab.Pane> */}

                  <div className="btn-group my-4 d-flex justify-center gap-3">
                    {activeTab > 1 ? (
                      <ButtonComponent
                        cssClass="e-info"
                        className="!capitalize"
                        onClick={() => toggleTab(activeTab - 1)}
                      >
                        Previous
                      </ButtonComponent>
                    ) : null}
                    {activeTab !== 4 ? (
                      <ButtonComponent
                        cssClass="e-info"
                        className="!capitalize"
                        onClick={() => toggleTab(activeTab + 1)}
                      >
                        Next
                      </ButtonComponent>
                    ) : null}
                    <ButtonComponent
                      cssClass="e-success"
                      className="!capitalize"
                      disabled={isLoading}
                      onClick={submitData}
                    >
                      {isLoading ? "Loading..." : "Submit"}
                    </ButtonComponent>
                  </div>
                </Tab.Container>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Transactions;
