# **Healthy.how server repository**

Please refer this notes for setting up project server

## **Packages used**

[db-migrate](https://db-migrate.readthedocs.io/en/latest/)

## **Database migrations for adding tables to empty database**

All the migration files that is usefull for creating table is in `migrations` folder

#### Database connection settings for running migrations is in `db-config` folder,

#### folder structure is

```
db-config/
    dev.json
    prod.json
```

## **For Running migrations use this commands**

#### Local database:

`yarn migration up --config db-config/dev.json`

#### Production database:

`yarn migration up --config db-config/prod.json`

or even simple

### For up migration in developement mode, run

`yarn migration-up-dev`

### For up migration in production mode, run

`yarn migration-up-prod`

## JWT:

### Generate jwt secret key using native crypto module

#### copy and paste below command in terminal

`node -e "console.log(require('crypto').randomBytes(256).toString('base64'));"`
#   s u p e r e v a l - b a c k e n d  
 