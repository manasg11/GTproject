const express = require("express");

const { withoutAuth } = require("../middlewares/withoutAuth");
const {
  addClosingPrice,
  getClosingPriceById,
  getClosingPrice,
  createClosingPrice,
  deleteAll,
} = require("../controllers/closing-price.controller");

const router = express.Router();

router.post("/add-closing-price", addClosingPrice);
router.post("/closing-price", createClosingPrice);
router.get("/closing-price-id", getClosingPriceById);
router.get("/closing-price", getClosingPrice);
router.delete("/closing-price", deleteAll)
module.exports = router;
