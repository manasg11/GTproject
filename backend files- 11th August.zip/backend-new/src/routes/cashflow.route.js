const express = require("express");

const { withoutAuth } = require("../middlewares/withoutAuth");

const {
  addCashFlow,
  getCashFlowById,
  getCashFlow,
  createCashFlow,
  deleteAll,
} = require("../controllers/cashflow.controller");

const router = express.Router();

router.post("/add-cash-flow", addCashFlow);
router.post("/cash-flow", createCashFlow);
router.get("/cash-flow-id", getCashFlowById);
router.get("/cash-flow", getCashFlow);
router.delete("/cash-flow", deleteAll);

module.exports = router;
