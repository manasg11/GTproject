const express = require("express");

const { withoutAuth } = require("../middlewares/withoutAuth");
const {
  addCorporateAction,
  getCorporateActionById,
  getCorporateAction,
  createCorporateAction,
  deleteAll,
} = require("../controllers/corporate-action.controller");

const router = express.Router();

router.post("/add-corporate-action", addCorporateAction);
router.post("/corporate-action", createCorporateAction);
router.get("/corporate-action-id", getCorporateActionById);
router.get("/corporate-action", getCorporateAction);
router.delete("/corporate-action", deleteAll);

module.exports = router;
