const DB = require("../sequelize/sequelize.config");
const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");
// const { generateOTP, sendOTP } = require("../services/otp.service");
const AppError = require("../utils/appError");

const addTransectionData = async (req, res, next) => {
  try {
    const {
      TransactionID,
      TransactionDate,
      SecurityDesc,
      BuyQty,
      TradeAmount,
      TradePrice,
      TradeCharge,
      CapitalFlow,
      BrokerName,
    } = req.body;

    const data = {
      transection_id : TransactionID,
      transection_date : TransactionDate,
      security_description: SecurityDesc,
      buy_quantity: BuyQty,
      trade_amount: TradeAmount,
      trade_price: TradePrice,
      trade_charge: TradeCharge,
      capital_flow: CapitalFlow,
      broker_name: BrokerName,
    };

    console.log({ data });

    const transectionData = await DB.TransectionData.create(data);

    return res.status(200).json({
      success: true,
      message: "Data Created Successfully",
      transectionData,
      // token,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};


const createTransectionsData = async (req, res, next) => {
  console.log("Hiiii")
  // try {
    const transectionsDataArray = req.body;
    // console.log({transectionsData})
    for (const transectionsData of transectionsDataArray) {
      try {
        const data = {
          TransactionID: transectionsData.TransactionID,
          TransactionDate: transectionsData.TransactionDate,
          SecurityDesc: transectionsData.SecurityDesc,
          BuyQty: transectionsData.BuyQty,
          TradeAmount: transectionsData.TradeAmount,
          TradePrice: transectionsData.TradePrice,
          TradeCharge: transectionsData.TradeCharge,
          CapitalFlow: transectionsData.CapitalFlow,
          AccountName: transectionsData.BrokerName,
          SellQty: transectionsData.SellQty,
        };
        const transectionsDataRecord = await DB.TransectionData.create(data);
        console.log({transectionsDataRecord})
      } catch (err) {
        console.log(err);
      }
    }
    return res.status(200).json({
      success: true,
      message: "Transections Data created successfully",
    });
  // } catch (err) {
  //   console.log(err);
  //   return res.status(500).json({ message: "Internal server error" });
  // }
};


const getTransectionDataById = async (req, res, next) => {
  try {
    const { id } = req.body;
    const transectionData = await DB.TransectionData.findOne({ where: { id: id } });
    if (!transectionData) {
      throw new AppError(409, "Transection data not found");
    }

    return res.status(200).json({
      success: true,
      message: "Transection data retrieved successfully",
      transectionData,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getTransectionData = async (req, res, next) => {
  try {
    const transectionData = await DB.TransectionData.findAll();
    if (!transectionData || transectionData.length === 0) {
      throw new AppError(409, "Transection data not found");
    }

    return res.status(200).json({
      success: true,
      message: "Transection data retrieved successfully",
      transectionData,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const deleteAll = async (req, res, next) => {
  try {
    await DB.TransectionData.destroy({
      where: {},
      truncate: true
    });
    return res.status(200).json({
      success: true,
      message: "Closing price deleted successfully"
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
}

module.exports = {
  addTransectionData,createTransectionsData,getTransectionDataById,getTransectionData, deleteAll
};
