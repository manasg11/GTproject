const DB = require("../sequelize/sequelize.config");
const AppError = require("../utils/appError");

const addCorporateAction = async (req, res, next) => {
  try {
    const {
      Date,
      ExDate,
      SName1,
      SID1,
      ActionType,
      Ratio,
      SName2,
      SID2,
      Ratio2,
    } = req.body;

    const data = {
      date :Date,
      ex_date: ExDate,
      s_name1: SName1,
      sid_1: SID1,
      action_type: ActionType,
      ratio: Ratio,
      s_name2: SName2,
      sid_2: SID2,
      ratio2: Ratio2,
    };

    console.log({ data });

    const corporateAction = await DB.CorporateAction.create(data);

    return res.status(200).json({
      success: true,
      message: "Corporate Action Created Successfully",
      corporateAction,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const createCorporateAction = async (req, res, next) => {
  try {
    const corporateActionArray = req.body;
    for (const corporateAction of corporateActionArray) {
      try {
        // const data = {
        //   date: corporateAction.Date,
        //   ex_date: corporateAction.ExDate,
        //   s_name1: corporateAction.SName1,
        //   sid_1: corporateAction.SID1,
        //   action_type: corporateAction.ActionType,
        //   ratio: corporateAction.Ratio,
        //   s_name2: corporateAction.SName2,
        //   sid_2: corporateAction.SID2,
        //   ratio2: corporateAction.Ratio2,
        // };
        const corporateActionData = await DB.CorporateAction.create(corporateAction);
      } catch (err) {
        console.log(err);
      }
    }
    return res.status(200).json({
      success: true,
      message: "Corporate Action data created successfully",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const deleteAll = async (req, res, next) => {
  try {
    await DB.CorporateAction.destroy({
      where: {},
      truncate: true
    });
    return res.status(200).json({
      success: true,
      message: "Closing price deleted successfully"
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
}

const getCorporateActionById = async (req, res, next) => {
  try {
    const { id } = req.body;
    const data = await Project.findOne({ where: { id: id } });
    if (!data) {
      console.log({ data });
      throw new AppError(409, "data is not found");
    }

    return res.status(200).json({
      success: true,
      message: "data get successfully",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getCorporateAction = async (req, res, next) => {
  try {
    const corporateAction = await DB.CorporateAction.findAll();
    if (!corporateAction || corporateAction.length === 0) {
      throw new AppError(409, "Corporate action not found");
    }

    return res.status(200).json({
      success: true,
      message: "Corporate action retrieved successfully",
      corporateAction,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  addCorporateAction,
  getCorporateActionById,
  getCorporateAction,
  createCorporateAction,
  deleteAll
};
