const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const catchAsync = require("./utils/catchAsync");
const DB = require("./sequelize/sequelize.config");
const { errorConverter, errorHandler } = require("./utils/error");
const transectionsDataRoute = require("./routes/transection-data.route");
const closingPriceRoute = require("./routes/closing-price.route");
const corporateActionRoute = require("./routes/corporate-action.route");
const cashFlowRoute = require("./routes/cashflow.route");

// const whitelist = ["http://localhost:3000"];

// const corsOptions: CorsOptions = {
//   origin: (origin: string | undefined, callback: CallableFunction) => {
//     if (whitelist.indexOf(origin as string) !== -1) {
//       callback(null, true);
//     } else {
//       callback(
//         new Error(
//           "Using strict cors policy, requst to resources is failed due to cors error!"
//         )
//       );
//     }
//   },
// };

const app = express();

console.log('first--------')
app.use(cors());
app.use(express.json({ limit: '100mb' }));

app.use(morgan("dev"));

app.use(express.urlencoded({ extended: true }));

app.use(express.json());

app.use("/transection-data", transectionsDataRoute);
app.use("/closing-price", closingPriceRoute);
app.use("/corporate-action", corporateActionRoute);
app.use("/cash-flow", cashFlowRoute);

app.use(errorConverter);

app.use(errorHandler);

module.exports = app;
