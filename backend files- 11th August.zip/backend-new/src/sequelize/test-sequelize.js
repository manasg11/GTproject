import DB from "./sequelize.config";

export const runSequlize = async () => {
  try {
    const response = await DB.sequelize.authenticate();
    console.log("Sequlize response >>>", response);
  } catch (err) {
    console.error("Something went wrong while connecting to database: ", err);
  }
};

runSequlize();
