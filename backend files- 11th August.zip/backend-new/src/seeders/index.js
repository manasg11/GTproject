// import foodListSeeder from "./food-list.seeder";
// import oxfordQuestionnaireQuestionsSeeder from "./oxford-questionnaire-questions.seeder";

const seeder = async () => {
  try {
    await Promise.all([oxfordQuestionnaireQuestionsSeeder(), foodListSeeder()]);
    console.log(
      `------------------------------\n✅ Seeders executed successfully.\n------------------------------`
    );
  } catch (err) {
    console.log("Error generated while runnig seeders: caused in seeder", err);
  }
};

seeder();
