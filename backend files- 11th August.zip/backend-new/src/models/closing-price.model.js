const { DataTypes, Sequelize } = require("sequelize");

const ClosingPriceModel = (sequelize) => {
  return sequelize.define(
    "paa_closingprice_input",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      AsOnDate: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      SecurityName: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Value: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      // created_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
      // updated_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
    },
    {
      tableName: "paa_closingprice_input",
      timestamps: false,
    }
  );
};

module.exports = ClosingPriceModel;
