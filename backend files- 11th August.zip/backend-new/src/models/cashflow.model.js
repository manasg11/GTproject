const { DataTypes, Sequelize } = require("sequelize");

const CashFlowModel = (sequelize) => {
  return sequelize.define(
    "paa_cashflow",
    {
      // id: {
      //   type: DataTypes.INTEGER,
      //   primaryKey: true,
      //   autoIncrement: true,
      //   allowNull: true,
      //  },
      CashFlowID: {
        type: DataTypes.INTEGER,
        allowNull: true,
        primaryKey: true,
      },
      CashFlowDate: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      Account: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Description: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Cashin: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Cashout: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      // created_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
      // updated_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
    },
    {
      tableName: "paa_cashflow",
      timestamps: false,
    }
  );
};

module.exports = CashFlowModel;
