const { DataTypes, Sequelize } = require("sequelize");

const CorporateActionModel = (sequelize) => {
  return sequelize.define(
    "paa_corporateaction",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      Date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      ExDate: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      SName1: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      SID1: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      ActionType: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Ratio: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      SName2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      SID2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      Ratio2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      // created_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
      // updated_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
    },
    {
      tableName: "paa_corporateaction",
      timestamps: false,
    }
  );
};

module.exports = CorporateActionModel;
