const { DataTypes, Sequelize } = require("sequelize");

const TransectionDataModel = (sequelize) => {
  return sequelize.define(
    "paa_tradetransaction_dump",
    {
      // id: {
      //   type: DataTypes.INTEGER,
      //   primaryKey: true,
      //   autoIncrement: true,
      //   allowNull: true,
      // },
      TransactionID: {
        type: DataTypes.STRING,
        primaryKey: true,
        allowNull: true,
      },
      TransactionDate: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      SecurityDesc: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      BuyQty: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      TradeAmount: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      TradePrice: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      TradeCharge: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      CapitalFlow: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      SellQty: {
        type: DataTypes.DECIMAL,
        allowNull: true,
      },
      AccountName: {
        type: DataTypes.STRING,
        allowNull: true,
      }
      // created_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
      // updated_at: {
      //   type: DataTypes.DATE,
      //   defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      // },
    },
    {
      tableName: "paa_tradetransaction_dump",
      timestamps: false,
    }
  );
};

module.exports = TransectionDataModel;
