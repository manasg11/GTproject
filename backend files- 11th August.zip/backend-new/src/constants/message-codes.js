class MessageCodes {
    static user_not_found_with_email_address = "user_with_email_not_found";
    static wrong_password = "wrong_password";
    static login_success = "login_success";
    static email_is_used = "email_is_used";
    static otp_verification_succes = "otp_verification_succes";
    static otp_expired = "otp_expired";
    static invalid_otp = "invalid_otp";
  }
  
  class CommonMessageCodes {
    static internal_server_error = "internal_server_error";
    static RESPONSE_SUCCESS = "RESPONSE_SUCCESS";
  }
  
  class AuthMessageCodes {
    static user_not_found = "user_not_found";
    static otp_verification_success = "otp_verification_success";
    static bearer_token_not_found = "bearer_token_not_found";
    static token_expired_error = "token_expired_error";
    static otp_not_stored_to_db = "otp_not_stored_to_db";
    static failed_to_sent_otp_on_phone = "failed_to_sent_otp_on_phone";
    static failed_while_working_on_otp = "failed_while_working_on_otp";
    static resend_phone_verification_code_success =
      "resend_phone_verification_code_success";
    static resend_phone_verification_code_failed =
      "resend_phone_verification_code_failed";
    static phone_is_already_verified = "phone_is_already_verified";
  }
  
  class UsersDietMessageCodes {
    static DIET_RECORD_SAVE_SUCCESS = "DIET_RECORD_SAVE_SUCCESS";
  }
  
  module.exports = {
    MessageCodes,
    CommonMessageCodes,
    AuthMessageCodes,
    UsersDietMessageCodes,
  };
  