/* Replace with your SQL commands */


CREATE TABLE IF NOT EXISTS `transections_data` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `transection_id` varchar(100) NULL,
    `transection_date` TIMESTAMP NULL,
    `security_description` VARCHAR(255) NULL,
    `buy_quantity` varchar(100) NULL,
    `trade_amount` varchar(100) NULL,
    `trade_price` varchar(100) NULL,
    `trade_charge` varchar(100) NULL,
    `capital_flow` varchar(100) NULL,
    `broker_name` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

