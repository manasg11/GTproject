/* Replace with your SQL commands */


CREATE TABLE IF NOT EXISTS `corporate_action` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `date` DATE NULL,
    `ex_date` DATE NULL,
    `s_name1` VARCHAR(255) NULL,
    `sid_1` VARCHAR(100) NULL,
    `action_type` VARCHAR(50) NULL,
    `ratio` VARCHAR(50) NULL,
    `s_name2` VARCHAR(255) NULL,
    `sid_2` VARCHAR(100) NULL,
    `ratio2` VARCHAR(50) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

