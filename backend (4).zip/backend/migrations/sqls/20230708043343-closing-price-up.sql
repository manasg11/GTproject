/* Replace with your SQL commands */



CREATE TABLE IF NOT EXISTS `closing_price` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `date` DATE NULL,
    `security` VARCHAR(255) NULL,
    `close` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);