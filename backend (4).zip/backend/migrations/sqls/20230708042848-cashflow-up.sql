/* Replace with your SQL commands */


CREATE TABLE IF NOT EXISTS `cashflow` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `cash_flow_id` INT(11) NULL,
    `cash_flow_date` DATE NULL,
    `account` VARCHAR(255) NULL,
    `description` VARCHAR(255) NULL,
    `cashin` VARCHAR(255) NULL,
    `cashout` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);

