require("dotenv").config();

class DbConstants {
  static get dbHost() {
    return process.env.DB_HOST || process.env.DEV_DB_HOST;
  }

  static get port() {
    return Number(process.env.DB_PORT || process.env.DEV_DB_PORT);
  }

  static get dbName() {
    return process.env.DB_NAME || process.env.DEV_DB_NAME;
  }

  static get userName() {
    return process.env.DB_USERNAME || process.env.DEV_DB_USERNAME;
  }

  static get password() {
    return process.env.DB_PASSWORD || process.env.DEV_DB_PASSWORD;
  }

  static get dialect() {
    return process.env.DB_DIALECT;
  }
}

class EnvironmentVariables {
  static get jwtSecret() {
    return process.env.JWT_SECRET;
  }

  static get gupshupSmsApi() {
    return process.env.GUPSHUP_SMS_API;
  }

  static get gupshupApiKey() {
    return process.env.GUPSHUP_API_KEY;
  }

  static get gupshupAppId() {
    return process.env.GUPSHUP_APP_ID;
  }
}

module.exports = { DbConstants, EnvironmentVariables };
