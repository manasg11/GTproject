const app = require ("./app")
// import conn from "../conn";

const port = process.env.PORT || 5000;
console.log('first')
app.listen(port, () => {
  console.info(`Server is listening on port ${port}...`);
});

