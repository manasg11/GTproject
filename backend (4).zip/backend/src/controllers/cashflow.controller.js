const DB = require("../sequelize/sequelize.config");
const AppError = require("../utils/appError");

const addCashFlow = async (req, res, next) => {
  try {
    const {
      CashFlowID,
      CashFlowDate,
      Account,
      Description,
      Cashin,
      Cashout,
    } = req.body;

    const data = {
      cash_flow_id: CashFlowID,
      cash_flow_date: CashFlowDate,
      account: Account,
      description: Description,
      cashin: Cashin,
      cashout: Cashout,
    };

    console.log({ data });

    const cashFlow = await DB.CashFlow.create(data);

    return res.status(200).json({
      success: true,
      message: "Cash Flow Created Successfully",
      cashFlow,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const createCashFlow = async (req, res, next) => {
  try {
    const cashFlowArray = req.body;
    for (const cashFlow of cashFlowArray) {
      try {
        const data = {
          cash_flow_id: cashFlow.CashFlowID,
          cash_flow_date: cashFlow.CashFlowDate,
          account: cashFlow.Account,
          description: cashFlow.Description,
          cashin: cashFlow.Cashin,
          cashout: cashFlow.Cashout,
        };
        const cashFlowData = await DB.CashFlow.create(data);
      } catch (err) {
        console.log(err);
      }
    }
    return res.status(200).json({
      success: true,
      message: "Cash Flow  data Created Successfully",
    });
  } catch (err) {
    console.log(err);
  }
};

const getCashFlowById = async (req, res, next) => {
  try {
    const { id } = req.body;
    const cashFlow = await DB.CashFlow.findOne({ where: { id: id } });
    if (!cashFlow) {
      throw new AppError(409, "Cash flow not found");
    }

    return res.status(200).json({
      success: true,
      message: "Cash flow retrieved successfully",
      cashFlow,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getCashFlow = async (req, res, next) => {
  try {
    const cashFlow = await DB.CashFlow.findAll();
    if (!cashFlow || cashFlow.length === 0) {
      throw new AppError(409, "Cash flow not found");
    }

    return res.status(200).json({
      success: true,
      message: "Cash flow retrieved successfully",
      cashFlow,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  addCashFlow,
  createCashFlow,
  getCashFlowById,
  getCashFlow,
};
