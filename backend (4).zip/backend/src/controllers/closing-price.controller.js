const DB = require("../sequelize/sequelize.config");
const AppError = require("../utils/appError");

const addClosingPrice = async (req, res, next) => {
  try {
    const { Date, SECURITY, CLOSE } = req.body;

    const data = {
      date: Date,
      security: SECURITY,
      close: CLOSE,
    };

    console.log({ data });

    const closingPrice = await DB.ClosingPrice.create(data);

    return res.status(200).json({
      success: true,
      message: "Closing Price Created Successfully",
      closingPrice,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const createClosingPrice = async (req, res, next) => {
    try {
      const closingPriceArray = req.body;
      for (const closingPrice of closingPriceArray) {
        try {
          const data = {
            date: closingPrice.Date,
            security: closingPrice.SECURITY,
            close: closingPrice.CLOSE,
          };
          const closingPriceData = await DB.ClosingPrice.create(data);
        } catch (err) {
          console.log(err);
        }
      }
      return res.status(200).json({
        success: true,
        message: "Closing Price data created successfully",
      });
    } catch (err) {
      console.log(err);
      return res.status(500).json({ message: "Internal server error" });
    }
  };
  


const getClosingPriceById = async (req, res, next) => {
  try {
    const { id } = req.body;
    const closingPrice = await DB.ClosingPrice.findOne({ where: { id: id } });
    if (!closingPrice) {
      throw new AppError(409, "Closing price not found");
    }

    return res.status(200).json({
      success: true,
      message: "Closing price retrieved successfully",
      closingPrice,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getClosingPrice = async (req, res, next) => {
  try {
    const closingPrice = await DB.ClosingPrice.findAll();
    if (!closingPrice || closingPrice.length === 0) {
      throw new AppError(409, "Closing price not found");
    }

    return res.status(200).json({
      success: true,
      message: "Closing price retrieved successfully",
      closingPrice,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  addClosingPrice,
  getClosingPriceById,
  getClosingPrice,
  createClosingPrice
};
