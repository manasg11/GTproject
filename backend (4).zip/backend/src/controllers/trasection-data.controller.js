const DB = require("../sequelize/sequelize.config");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");
// const { generateOTP, sendOTP } = require("../services/otp.service");
const AppError = require("../utils/appError");

const addTransectionData = async (req, res, next) => {
  try {
    const {
      TransactionID,
      TransactionDate,
      SecurityDesc,
      BuyQty,
      TradeAmount,
      TradePrice,
      TradeCharge,
      CapitalFlow,
      BrokerName,
    } = req.body;

    const data = {
      transection_id : TransactionID,
      transection_date : TransactionDate,
      security_description: SecurityDesc,
      buy_quantity: BuyQty,
      trade_amount: TradeAmount,
      trade_price: TradePrice,
      trade_charge: TradeCharge,
      capital_flow: CapitalFlow,
      broker_name: BrokerName,
    };

    console.log({ data });

    const transectionData = await DB.TransectionData.create(data);

    return res.status(200).json({
      success: true,
      message: "Data Created Successfully",
      transectionData,
      // token,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};


const createTransectionsData = async (req, res, next) => {
  try {
    const transectionsDataArray = req.body;
    for (const transectionsData of transectionsDataArray) {
      try {
        const data = {
          transection_id: transectionsData.TransactionID,
          transection_date: transectionsData.TransactionDate,
          security_description: transectionsData.SecurityDesc,
          buy_quantity: transectionsData.BuyQty,
          trade_amount: transectionsData.TradeAmount,
          trade_price: transectionsData.TradePrice,
          trade_charge: transectionsData.TradeCharge,
          capital_flow: transectionsData.CapitalFlow,
          broker_name: transectionsData.BrokerName,
        };
        const transectionsDataRecord = await DB.TransectionData.create(data);
      } catch (err) {
        console.log(err);
      }
    }
    return res.status(200).json({
      success: true,
      message: "Transections Data created successfully",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};


const getTransectionDataById = async (req, res, next) => {
  try {
    const { id } = req.body;
    const transectionData = await DB.TransectionData.findOne({ where: { id: id } });
    if (!transectionData) {
      throw new AppError(409, "Transection data not found");
    }

    return res.status(200).json({
      success: true,
      message: "Transection data retrieved successfully",
      transectionData,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getTransectionData = async (req, res, next) => {
  try {
    const transectionData = await DB.TransectionData.findAll();
    if (!transectionData || transectionData.length === 0) {
      throw new AppError(409, "Transection data not found");
    }

    return res.status(200).json({
      success: true,
      message: "Transection data retrieved successfully",
      transectionData,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  addTransectionData,createTransectionsData,getTransectionDataById,getTransectionData
};
