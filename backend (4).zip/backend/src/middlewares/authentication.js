const jwt = require('jsonwebtoken');
const { EnvironmentVariables } = require('../constants/constants');
const DB = require('../sequelize/sequelize.config');
const { AuthMessageCodes } = require('../constants/message-codes');

const authenticateUser = async (req, res, next) => {
  try {
    let token = req.headers.authorization || req.headers['Authorization'];

    if (!token) {
      return res.status(401).json({
        success: false,
        data: null,
        message: 'Unauthorized',
        message_code: 'bearer_token_not_found',
        errors: {
          token_not_found: 'Bearer token not found!',
        },
      });
    }

    token = token.replace('Bearer ', '').trim();
    const decoded = jwt.verify(token, EnvironmentVariables.jwtSecret);
    if (decoded.id) {
      const user = await DB.User.findOne({
        where: { id: decoded.id },
      });

      req.user = user;
    }
    next();
  } catch (err) {
    let msg_code = err.name;

    if (msg_code === 'TokenExpiredError') {
      msg_code = AuthMessageCodes.token_expired_error;
    }
    return res.status(401).json({
      success: false,
      data: null,
      message: 'Unauthorized',
      message_code: msg_code,
      errors: {
        error: err.message,
      },
    });
  }
};

module.exports = authenticateUser;
