const jwt = require('jsonwebtoken');
const { EnvironmentVariables } = require('../constants/constants');
const DB = require('../sequelize/sequelize.config');
const { AuthMessageCodes } = require('../constants/message-codes');

const withoutAuth = async (req, res, next) => {
  try {
    next();
  } catch (err) {
    console.log(err);
  }
};

module.exports = withoutAuth;
