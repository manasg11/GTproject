const { DataTypes, Sequelize } = require("sequelize");

const CorporateActionModel = (sequelize) => {
  return sequelize.define(
    "corporate_action",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      ex_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      s_name1: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      sid_1: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      action_type: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      ratio: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      s_name2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      sid_2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      ratio2: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
    },
    {
      tableName: "corporate_action",
      timestamps: false,
    }
  );
};

module.exports = CorporateActionModel;
