const { DataTypes, Sequelize } = require("sequelize");

const CashFlowModel = (sequelize) => {
  return sequelize.define(
    "cashflow",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      cash_flow_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      cash_flow_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      account: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      cashin: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      cashout: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
    },
    {
      tableName: "cashflow",
      timestamps: false,
    }
  );
};

module.exports = CashFlowModel;
