const { DataTypes, Sequelize } = require("sequelize");

const ClosingPriceModel = (sequelize) => {
  return sequelize.define(
    "closing_price",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: true,
      },
      date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      security: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      close: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
    },
    {
      tableName: "closing_price",
      timestamps: false,
    }
  );
};

module.exports = ClosingPriceModel;
