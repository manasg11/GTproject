const express = require("express");

const { withoutAuth } = require("../middlewares/withoutAuth");
const {
  addClosingPrice,
  getClosingPriceById,
  getClosingPrice,
  createClosingPrice,
} = require("../controllers/closing-price.controller");

const router = express.Router();

router.post("/add-closing-price", addClosingPrice);
router.post("/closing-price", createClosingPrice);
router.get("/closing-price-id", getClosingPriceById);
router.get("/closing-price", getClosingPrice);

module.exports = router;
