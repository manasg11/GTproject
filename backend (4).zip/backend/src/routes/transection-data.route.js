const express = require("express");
const {
  addTransectionData,
  getTransectionDataById,
  getTransectionData,
  createTransectionsData,
} = require("../controllers/trasection-data.controller");
const { withoutAuth } = require("../middlewares/withoutAuth");

const router = express.Router();

router.post("/add-transection-data", addTransectionData);
router.post("/transections-data", createTransectionsData);
router.get("/transection-data-id", getTransectionDataById);
router.get("/transection-data", getTransectionData);

module.exports = router;
