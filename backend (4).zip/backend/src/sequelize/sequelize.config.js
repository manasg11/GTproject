const { Sequelize } = require('sequelize');
const { DbConstants } = require('../constants/constants');
const TransectionDataModel = require('../models/transection-data.model');
const ClosingPriceModel = require('../models/closing-price.model');
const CorporateActionModel = require('../models/corporate-action.model');
const CashFlowModel = require('../models/cashflow.model');


const sequelize = new Sequelize(
  DbConstants.dbName,
  DbConstants.userName,
  DbConstants.password,
  {
    host: DbConstants.dbHost,
    dialect: DbConstants.dialect,
    pool: { max: 5, idle: 30 },
    port: DbConstants.port,
    sync: {
      force: true,
      alter: true
    }
  }
);

sequelize.authenticate();

const DB = {
  sequelize, // connection instance (RAW queries)
  Sequelize, // library
  TransectionData : TransectionDataModel(sequelize),
  ClosingPrice: ClosingPriceModel(sequelize),
  CorporateAction: CorporateActionModel(sequelize),
  CashFlow: CashFlowModel(sequelize),
};


module.exports = DB;