
// module.exports = {
//   apps: [
//     {
//       name: "server",
//       script: "./dist/server.js",
//       env: {
//         NODE_ENV: "development",
//         PORT: 5000,
//         DEV_DB_HOST: "localhost",
//         DEV_DB_PORT: 5432,
//         DEV_DB_NAME: "healthy-how-production-db",
//         DEV_DB_USERNAME: "postgres",
//         DEV_DB_PASSWORD: "postgres@321",
//         JWT_SECRET:
//           "K8T4unOdOHblmhAHJaBSVu2WVOgVVOP7j6i1T0pC4uBM26MdY9+Wy3xN4wpazIqpivkRA/JJUgBAXHps1xkfah2iPdzvfJpdJRitOU75ugLcDTbH6pQs2ixasuTzyGPxa/nvZGLtN+AWiObmfFOqcoevqPkKCYeW6AtMaXWz3uD4zq/PG9+UTZs3ZJLXSA+Ig2Zn35p0Z1Ou130aU9HLrscuNyIKpKiKhd770tna2Uh6yM69yfl5lBv7EHtaeDabvOnuL1LkPjW0RKg2f7YUN6ffC40vG773u8VF8Feva5K7iSCZ4fC7DsUjP+V9apRKODDLOMeKrzd0l/sfEOFZcQ==",
//         DB_DIALECT: "postgres",
//         GUPSHUP_SMS_API: "http://api.gupshup.io/sms/v1/message",
//         GUPSHUP_API_KEY: "zwgxcoctsveerbvelfvo83uhqip3pauy",
//         GUPSHUP_APP_ID: "33c48956-bd96-4128-938a-7898f9160053",
//       },
//       env_test: {
//         NODE_ENV: "test",
//       },
//       env_staging: {
//         NODE_ENV: "staging",
//       },
//       env_production: {
//         NODE_ENV: "production",
//       },
//     },
//   ],
// };
